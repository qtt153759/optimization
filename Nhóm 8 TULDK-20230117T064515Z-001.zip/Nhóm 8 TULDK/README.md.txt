File bao gồm:
+)Báo cáo
+)Slide
+)File Source code (Đã bao gồm testcase)

Chạy code: 

Bước 1: Tạo máy ảo python:
Bước 2: Cài đặt requirement: 
	pip install -r requirements.txt
Bước 3: Chạy các thuật toán
	Đi đến các thư mục chứa code 
	Chỉnh sửa đường dẫn tập test (nếu cần thiết)
	chạy file .py

	vd: muốn chạy thuật toán IP
	
	cd src/interger_programing
	python3 IP.py