# TULKH-20212


The Share-a-Ride Problem - 


# requirement
pip install -r requirements.txt

