cd src/backtracking
python3 main.py || python main.py
