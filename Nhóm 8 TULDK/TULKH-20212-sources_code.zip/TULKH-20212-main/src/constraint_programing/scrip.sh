
source .venv/bin/activate

cd src/constraint_programing

python3 CP.py