
source .venv/bin/activate

cd src/interger_programing

python3 IP.py