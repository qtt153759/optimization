run model tabu search by parsing arguments in Eclipse

"Tabu 1 small"
"Tabu 1 medium"
"Tabu 1 huge"