package model;



public class A {
	public static void main(String[] args) {
		System.out.println("aaaa");
		System.out.println(args[0]);
	}
}
